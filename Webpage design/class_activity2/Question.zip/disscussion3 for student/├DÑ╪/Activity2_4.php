<?php
  echo"*";
?>