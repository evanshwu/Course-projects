<?php
  result(95);
  result(40);
  result(85);
  result(65);

?>